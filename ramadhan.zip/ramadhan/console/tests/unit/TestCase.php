<?php

namespace console\tests\unit;

class TestCase extends \yii\codeception\TestCase
{
    public $appConfig = '@console/tests/unit/_config.php';
}
