<?php

namespace frontend\tests\unit;

class TestCase extends \yii\codeception\TestCase
{
    public $appConfig = '@frontend/tests/unit/_config.php';
}
