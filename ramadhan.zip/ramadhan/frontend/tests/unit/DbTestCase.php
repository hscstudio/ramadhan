<?php

namespace frontend\tests\unit;

class DbTestCase extends \yii\codeception\DbTestCase
{
    public $appConfig = '@frontend/tests/unit/_config.php';
}
