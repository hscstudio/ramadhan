<?php

namespace common\tests\unit;

class DbTestCase extends \yii\codeception\DbTestCase
{
    public $appConfig = '@common/tests/unit/_config.php';
}
