<?php

namespace common\tests\unit;

class TestCase extends \yii\codeception\TestCase
{
    public $appConfig = '@common/tests/unit/_config.php';
}
