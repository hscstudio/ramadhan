<?php

namespace backend\modules\pusdiklat\planning;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\pusdiklat\planning\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
